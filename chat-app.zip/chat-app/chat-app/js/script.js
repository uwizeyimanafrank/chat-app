document.addEventListener("DOMContentLoaded", function () {
    let postButton = document.getElementById("post-button");
    let postContent = document.getElementById("post-content");
    let postFile = document.getElementById("post-file");
    let postsContainer = document.getElementById("posts-container");

    function fetchPosts() {
        fetch("php/get_posts.php")
            .then(response => response.text())
            .then(data => {
                postsContainer.innerHTML = data;
            });
    }

    postButton.addEventListener("click", function () {
        let formData = new FormData();
        formData.append("content", postContent.value);
        formData.append("file", postFile.files[0]);

        fetch("php/post.php", {
            method: "POST",
            body: formData
        }).then(response => {
            if (response.ok) {
                postContent.value = "";
                postFile.value = "";
                fetchPosts(); // Reload posts
            }
        });
    });

    setInterval(fetchPosts, 5000); // Auto-refresh every 5 seconds
});
