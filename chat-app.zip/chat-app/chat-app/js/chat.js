document.addEventListener("DOMContentLoaded", function () {
    let chatBox = document.getElementById("chat-box");
    let messageInput = document.getElementById("message-input");
    let sendButton = document.getElementById("send-button");
    let fileInput = document.getElementById("file-input");
    let receiverId = document.getElementById("receiver_id").value;

    let isUserAtBottom = true; // Track if the user is at the bottom

    // **Detect if user scrolls up (Prevent auto-scroll if reading old messages)**
    chatBox.addEventListener("scroll", function () {
        let distanceToBottom = chatBox.scrollHeight - chatBox.scrollTop - chatBox.clientHeight;
        isUserAtBottom = distanceToBottom < 10; 
    });
 
    // **Fetch messages every 2 seconds**
    function fetchMessages() {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "php/chat.php?receiver_id=" + receiverId, true);
        xhr.onload = function () {
            if (xhr.status == 200) {
                let oldHeight = chatBox.scrollHeight;
                chatBox.innerHTML = xhr.responseText;

                // **Only scroll if user was already at the bottom**
                if (isUserAtBottom || chatBox.scrollHeight > oldHeight) {
                    chatBox.scrollTop = chatBox.scrollHeight;
                }
            }
        };
        xhr.send();
    }

    // **Send text message**
    sendButton.addEventListener("click", function () {
        let message = messageInput.value.trim();
        if (message !== "") {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "php/chat.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function () {
                if (xhr.status == 200) {
                    messageInput.value = ""; // Clear input
                    fetchMessages();
                }
            };
            xhr.send("message=" + encodeURIComponent(message) + "&receiver_id=" + receiverId);
        }
    });

    // **Handle file upload**
    fileInput.addEventListener("change", function () {
        let file = fileInput.files[0];
        if (!file) return;

        let formData = new FormData();
        formData.append("file", file);
        formData.append("receiver_id", receiverId);

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "php/chat.php", true);
        xhr.onload = function () {
            if (xhr.status == 200) {
                fileInput.value = ""; // Clear file input
                fetchMessages();
            }
        };
        xhr.send(formData);
    });

    // **Auto-refresh messages every 2 seconds (only once)**
    setInterval(fetchMessages, 2000);
});
