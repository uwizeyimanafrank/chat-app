<?php
include "db.php";

$query = "SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<div class='post'>";
    echo "<h4>" . htmlspecialchars($row['username']) . "</h4>";
    echo "<p>" . htmlspecialchars($row['content']) . "</p>";
    if (!empty($row['file'])) {
        echo "<img src='uploads/" . $row['file'] . "' width='200'>";
    }
    echo "</div>";
}
?>
