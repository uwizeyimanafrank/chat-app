<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"])) {
    die("Unauthorized");
}

$user_id = $_SESSION["user_id"];
$content = mysqli_real_escape_string($conn, $_POST["content"]);

// Handle file upload (optional)
$file_name = "";
if (!empty($_FILES["file"]["name"])) {
    $target_dir = "../uploads/";
    $file_name = basename($_FILES["file"]["name"]);
    $target_file = $target_dir . $file_name;
    move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
}

$query = "INSERT INTO posts (user_id, content, file) VALUES ('$user_id', '$content', '$file_name')";
mysqli_query($conn, $query);
?>
