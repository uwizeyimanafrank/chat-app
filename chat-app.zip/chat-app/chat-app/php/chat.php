<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"])) {
    die("Unauthorized");
}

$user_id = $_SESSION["user_id"];

// **Handle Sending Message or File**
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $receiver_id = $_POST["receiver_id"];
    $message = isset($_POST["message"]) ? mysqli_real_escape_string($conn, $_POST["message"]) : "";
    $file_type = "text"; 
    $file_path = NULL;

    // **Check if a file was uploaded**
    if (!empty($_FILES["file"]["name"])) {
        $upload_dir = "uploads/";
        
        // Ensure the uploads directory exists
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = time() . "_" . basename($_FILES["file"]["name"]);
        $target_file = $upload_dir . $file_name;
        $file_ext = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // **Determine file type**
        if (in_array($file_ext, ["jpg", "jpeg", "png", "gif"])) {
            $file_type = "image";
        } elseif (in_array($file_ext, ["mp3", "wav", "ogg"])) {
            $file_type = "audio";
        } else {
            $file_type = "file"; // Any other file type (PDF, DOC, ZIP, etc.)
        }

        // **Move the uploaded file**
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            $file_path = $target_file; // Save the file path in the database
        }
    }

    // **Insert into database**
    $query = "INSERT INTO messages (sender_id, receiver_id, message, file_path, file_type) 
              VALUES ('$user_id', '$receiver_id', '$message', '$file_path', '$file_type')";
    mysqli_query($conn, $query);
    exit();
}

// **Fetch Messages**
$receiver_id = isset($_GET['receiver_id']) ? intval($_GET['receiver_id']) : 0;

$query = "SELECT * FROM messages WHERE 
         (sender_id = '$user_id' AND receiver_id = '$receiver_id') 
         OR (sender_id = '$receiver_id' AND receiver_id = '$user_id') 
         ORDER BY timestamp ASC ";

$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    $position = ($row['sender_id'] == $user_id) ? "sent" : "received";
    echo "<div class='message $position'>";

    if ($row['file_type'] == "image") {
        echo "<img src='php/" . htmlspecialchars($row['file_path']) . "' width='200' />";
    } elseif ($row['file_type'] == "audio") {
        echo "<audio controls><source src='php/" . htmlspecialchars($row['file_path']) . "' type='audio/mpeg'id='audio'></audio>";
    } elseif ($row['file_type'] == "file") {
        echo "<a href='" . htmlspecialchars($row['file_path']) . "' download>📄 Download File</a>";
    } else {
        echo htmlspecialchars($row['message']);
    }
    echo "</div>";
}
?>
